package de.okhatib.okbongov2.datenbase;

public class tbBongoPicture {
	protected int id;
	protected String name;
	protected  String editDate;
	protected String fullPath;
	protected  String pictureDescription;
}

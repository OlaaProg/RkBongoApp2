package de.okhatib.okbongov2.datenbase;

public class tblBongoNotes extends tblBongoLocation{
	private int id;
	private String name;
	private String editDate ;
	private int fKeyPicturedId;
	private int fKeyLocationId;
	private String noteContent;
}

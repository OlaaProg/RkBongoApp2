package de.okhatib.okbongov2.datenbase;

public class tblBongoLocation extends tbBongoPicture{
	protected int id;
	protected String name;
	protected String editDate;
	protected String latitude;
	protected String longitude;
	protected String altitude;
}

package de.okhatib.okbongov2.logic.handler;

import android.content.Context;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import de.okhatib.okbongov2.R;

public class DataHandler {
	
	private void DateHandler(){
	
	}
	
	public static synchronized String getCurrentDateAsString(Context context){
		String strDatePattern="dd.MM.yyyy";
		DateFormat dateFormat= new SimpleDateFormat(strDatePattern);
		Date currentDateAndTime=new Date();
		return dateFormat.format(currentDateAndTime);
	}
	public static synchronized String getPhotoTimeStamp(Context context){
		
		//TODO 1. Zeitstempel generieren
		String strImageTimeStampPattern = context.getString(R.string.strImageTimeStampPattern);
		
		//2. Aktuelle Zeit feststellen durch ein neue Date Objekts
		Date currentTime = new Date();
		
		//3. Datumsformatierung festlegen
		DateFormat simpleDateFormat = new SimpleDateFormat(strImageTimeStampPattern);
		
		
		return  simpleDateFormat.format(currentTime);
	}
}

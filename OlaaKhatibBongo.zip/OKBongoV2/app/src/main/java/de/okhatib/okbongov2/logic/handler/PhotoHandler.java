package de.okhatib.okbongov2.logic.handler;

public class PhotoHandler {
	private static final String TAG=PhotoHandler.class.getSimpleName();
	
	public PhotoHandler() {
	}
}
